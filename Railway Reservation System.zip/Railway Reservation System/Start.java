import GUI.*;

public class Start {
    public static void main(String[] args) {
        RailwayReservationPage rrs = new RailwayReservationPage();
        rrs.setVisible(true);
    }
}
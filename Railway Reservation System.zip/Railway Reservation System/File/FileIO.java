package File;
import Entity.*;
import java.io.*;
import java.util.*;

public class FileIO {
    public static void loadFromFile(Train[] trains) {
        try {
            
            File directory = new File("./File");
            if (!directory.exists()) {
                System.out.println("File directory not found. No data to load.");
                return; 
            }

            File trainFile = new File("./File/Trains.txt");
            if (trainFile.exists()) {
                Scanner sc = new Scanner(trainFile);
                while (sc.hasNextLine()) {
                    String data[] = sc.nextLine().split("\\|");
                    
                    if (data.length >= 8) { 
                        int trainIndex = Integer.parseInt(data[0]);
                        String trainNumber = data[1];
                        String trainName = data[2];
                        String From = data[3];
                        String destination = data[4];
                        String departureTime = data[5];
                        String arrivalTime = data[6];
                        double ticketPrice = Double.parseDouble(data[7]);
                        
                       
                        if (trainIndex >= 0 && trainIndex < trains.length) {
                             trains[trainIndex] = new Train(trainNumber, trainName, From, 
                                                         destination, departureTime, arrivalTime, ticketPrice);
                        }
                    }
                }
                sc.close();
            } else {
                System.out.println("Trains.txt not found. No train data loaded.");
            }
            
            
            File passengerFile = new File("./File/Passengers.txt");
            if (passengerFile.exists()) {
                Scanner sc = new Scanner(passengerFile);
                while (sc.hasNextLine()) {
                    String data[] = sc.nextLine().split("\\|");
                
                    if (data.length >= 8) { 
                        int trainIndex = Integer.parseInt(data[0]);
                        int seatIndex = Integer.parseInt(data[1]);
                        String passengerName = data[2];
                        int age = Integer.parseInt(data[3]);
                        String gender = data[4];
                        String phoneNumber = data[5];
                        String seatNumber = data[6]; 
                        double ticketPrice = Double.parseDouble(data[7]); 
                        
                        if (trainIndex >= 0 && trainIndex < trains.length && trains[trainIndex] != null) {
                            Passenger p = new Passenger(passengerName, age, gender, phoneNumber, seatNumber, ticketPrice);
                            trains[trainIndex].addPassenger(p, seatIndex);
                        }
                    }
                }
                sc.close();
            } else {
                System.out.println("Passengers.txt not found. No passenger data loaded.");
            }
        } catch (IOException e) {
            System.out.println("Error loading from file: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Data format error in file: " + e.getMessage());
        }
    }
    
    public static void saveChangesInFile(Train[] trains) {
        try {
            
            File directory = new File("./File");
            if (!directory.exists()) {
                directory.mkdirs();
            }

            try (
                BufferedWriter trainWriter = new BufferedWriter(new FileWriter("./File/Trains.txt"));
                BufferedWriter passengerWriter = new BufferedWriter(new FileWriter("./File/Passengers.txt"))
            ) {
                for (int trainIndex = 0; trainIndex < trains.length; trainIndex++) {
                    if (trains[trainIndex] != null) {
                        Train train = trains[trainIndex];
                        trainWriter.write(trainIndex + "|" + train.getTrainNumber() + "|" +
                                        train.getTrainName() + "|" + train.getFrom() + "|" +
                                        train.getDestination() + "|" + train.getDepartureTime() + "|" +
                                        train.getArrivalTime() + "|" + train.getTicketPrice() + "\n");

                        Passenger[] passengers = train.getAllPassengers();
                        for (int seatIndex = 0; seatIndex < passengers.length; seatIndex++) {
                            if (passengers[seatIndex] != null) {
                                Passenger p = passengers[seatIndex];
                                passengerWriter.write(trainIndex + "|" + seatIndex + "|" +
                                                    p.getPassengerName() + "|" + p.getAge() + "|" +
                                                    p.getGender() + "|" + p.getPhoneNumber() + "|" +
                                                    p.getSeatNumber() + "|" +
                                                    p.getTicketPrice() + "\n");
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }
}
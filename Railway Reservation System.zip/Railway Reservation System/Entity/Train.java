package Entity;

public class Train {
    private String trainNumber;
    private String trainName;
    private String From;
    private String destination;
    private String departureTime;
    private String arrivalTime;
    private double ticketPrice;
    private Passenger[] passengers = new Passenger[100]; 
    private boolean[] seatAvailability = new boolean[100]; 
    private int passengerCount;
    
    public Train() {
        initializeSeats();
    }
    
    public Train(String trainNumber, String trainName, String From, String destination, 
                String departureTime, String arrivalTime, double ticketPrice) {
        this.trainNumber = trainNumber;
        this.trainName = trainName;
        this.From = From;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.ticketPrice = ticketPrice;
        this.passengerCount = 0;
        initializeSeats();
    }
    
    private void initializeSeats() {
        for (int i = 0; i < 100; i++) {
            seatAvailability[i] = true; 
        }
    }
    
    
    public void setTrainNumber(String trainNumber) {
        this.trainNumber = trainNumber;
    }
    
    public String getTrainNumber() {
        return trainNumber;
    }
    
    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }
    
    public String getTrainName() {
        return trainName;
    }
    
    public void setFrom(String From) {
        this.From = From;
    }
    
    public String getFrom() {
        return From;
    }
    
    public void setDestination(String destination) {
        this.destination = destination;
    }
    
    public String getDestination() {
        return destination;
    }
    
    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }
    
    public String getDepartureTime() {
        return departureTime;
    }
    
    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }
    
    public String getArrivalTime() {
        return arrivalTime;
    }
    
    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }
    
    public double getTicketPrice() {
        return ticketPrice;
    }
    
    public int getPassengerCount() {
        return passengerCount;
    }
    
    public boolean addPassenger(Passenger p, int seatNumber) {
        if (seatNumber >= 0 && seatNumber < 100 && seatAvailability[seatNumber]) {
            passengers[seatNumber] = p;
            seatAvailability[seatNumber] = false;
            passengerCount++;
            return true;
        }
        return false;
    }
    
    public boolean removePassenger(int seatNumber) {
        if (seatNumber >= 0 && seatNumber < 100 && passengers[seatNumber] != null) {
            passengers[seatNumber] = null;
            seatAvailability[seatNumber] = true;
            passengerCount--;
            return true;
        }
        return false;
    }
    
    public int checkSeatAvailability(int seatNumber) {
        if (seatNumber >= 0 && seatNumber < 100) {
            if (seatAvailability[seatNumber]) {
                return 1; 
            } else {
                return 0; 
            }
        }
        return -1; 
    }
    
    public int getAvailableSeats() {
        int count = 0;
        for (int i = 0; i < 100; i++) {
            if (seatAvailability[i]) {
                count++;
            }
        }
        return count;
    }
    
    public Passenger getPassengerAtSeat(int seatNumber) {
        if (seatNumber >= 0 && seatNumber < 100) {
            return passengers[seatNumber];
        }
        return null;
    }
    
    public void showTrain() {
        System.out.println("Train Number: " + trainNumber);
        System.out.println("Train Name: " + trainName);
        System.out.println("From: " + From);
        System.out.println("Destination: " + destination);
        System.out.println("Departure: " + departureTime);
        System.out.println("Arrival: " + arrivalTime);
        System.out.println("Price:" + ticketPrice + "Taka");
        System.out.println("Available Seats: " + getAvailableSeats());
        System.out.println("-------------------------\n");
    }
    
    public String getTrain() {
        String data = "";
        data += "******** " + trainName + " **********\n";
        data += "Train Number: " + trainNumber + "\n";
        data += "Route: " + From + " to " + destination + "\n";
        data += "Departure: " + departureTime + "\n";
        data += "Arrival: " + arrivalTime + "\n";
        data += "Price: " + ticketPrice + "\n";
        data += "Available Seats: " + getAvailableSeats() + "\n";
        data += "*******************************\n";
        return data;
    }
    
    public String getReservedTickets() {
        String data = "";
        data += "******** Reserved Tickets - " + trainName + " **********\n";
        for (int i = 0; i < 100; i++) {
            if (passengers[i] != null) {
                data += "~~~~~~~~ Seat " + (i + 1) + " ~~~~~~~~\n";
                data += passengers[i].getPassenger();
            }
        }
        data += "*******************************\n";
        return data;
    }
    
    public Passenger[] getAllPassengers() {
        return passengers;
    }

    public boolean isSeatBooked(int seatIndex) {
        if (seatIndex >= 0 && seatIndex < 100) {
            return !seatAvailability[seatIndex];
        }
        return false;
    }

    public boolean bookSeat(int seatIndex, Passenger p) {
        if (seatIndex >= 0 && seatIndex < passengers.length && passengers[seatIndex] == null) {
            passengers[seatIndex] = p;
            return true;
        }
        return false;
    }

    public boolean cancelSeat(int seatIndex) {
        return removePassenger(seatIndex);
    }
}
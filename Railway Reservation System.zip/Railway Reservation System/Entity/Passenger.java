package Entity;

public class Passenger {
    private String passengerName;
    private int age;
    private String gender;
    private String phoneNumber;
    private String seatNumber;
    private double ticketPrice;
    
    public Passenger() {
      
    }
    
    public Passenger(String passengerName, int age, String gender, String phoneNumber, String seatNumber, double ticketPrice) {
        this.passengerName = passengerName;
        this.age = age;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
        this.seatNumber = seatNumber;
        this.ticketPrice = ticketPrice;
    }

   
    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }
    
    public String getPassengerName() {
        return passengerName;
    }
    
    public void setAge(int age) {
        this.age = age;
    }
    
    public int getAge() {
        return age;
    }
    
    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }
    
    public String getSeatNumber() {
        return seatNumber;
    }
    
    public void setTicketPrice(double ticketPrice) {
        this.ticketPrice = ticketPrice;
    }
    
    public double getTicketPrice() {
        return ticketPrice;
    }
    
    public void showPassenger() {
        System.out.println("Passenger Name: " + passengerName);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("Phone: " + phoneNumber);
        System.out.println("Seat: " + seatNumber);
        System.out.println("Price: " + ticketPrice +"Taka");
    }
    
    public String getPassenger() {
        return "Passenger Name: " + passengerName + "\n" +
               "Age: " + age + "\n" +
               "Gender: " + gender + "\n" +
               "Phone: " + phoneNumber + "\n" +
               "Seat: " + seatNumber + "\n" +
               "Price: " + ticketPrice + "\n";
    }
}
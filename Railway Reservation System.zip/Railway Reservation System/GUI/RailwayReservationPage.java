package GUI;

import Entity.*;
import File.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class RailwayReservationPage extends JFrame implements ActionListener {
    private Train[] trains = new Train[50];
    private DefaultTableModel trainTableModel, passengerTableModel;
    private JTable trainTable, passengerTable;

   
    JTextField trainNoTextField, trainNameTextField, sourceTextField, destinationTextField;
    JTextField departureTextField, arrivalTextField, priceTextField;
    JButton insertTrainButton, deleteTrainButton, saveButton, trainClearButton;

  
    JTextField pTrainNoTextField, seatNoTextField, nameTextField, ageTextField, phoneTextField;
    JComboBox<String> genderComboBox;
    JButton insertPassengerButton, deletePassengerButton, passengerClearButton, showReservedButton;

    
    JTextField searchTextField;
    JButton searchButton, refreshButton;

   
    JLabel availableSeatsLabel;

    public RailwayReservationPage() {
        super("Railway Reservation System");

     
        ImageIcon icon = new ImageIcon("./images/logo.png.png");
        setIconImage(icon.getImage());

        setSize(1100, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setLayout(null);

      
        ImageIcon bgImage = new ImageIcon("./images/bg.jpg.jpg");
        JLabel background = new JLabel(bgImage);
        background.setBounds(0, 0, 1100, 750);

      
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(null);
        contentPanel.setBackground(new Color(0, 0, 0, 200));
        contentPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2, true));
        contentPanel.setOpaque(true);
        contentPanel.setBounds(0, 80, 1100, 670);

      
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 10));
        topPanel.setOpaque(false);
        topPanel.setBounds(0, 0, 1100, 80);

        ImageIcon logoImage = new ImageIcon("./images/logo.png.png");
        Image scaledLogo = logoImage.getImage().getScaledInstance(75, 75, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogo));
        topPanel.add(logoLabel);

        JLabel titleLabel = new JLabel("  AIUB Railway Reservation System");
        titleLabel.setFont(new Font("Consolas", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel);

       
        JLabel trainNoLabel = new JLabel("Train No:");
        trainNoLabel.setBounds(20, 20, 100, 25);
        trainNoLabel.setForeground(Color.WHITE);
        trainNoLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(trainNoLabel);

        trainNoTextField = new JTextField();
        trainNoTextField.setBounds(120, 20, 150, 25);
        contentPanel.add(trainNoTextField);

        JLabel trainNameLabel = new JLabel("Train Name:");
        trainNameLabel.setBounds(20, 60, 100, 25);
        trainNameLabel.setForeground(Color.WHITE);
        trainNameLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(trainNameLabel);

        trainNameTextField = new JTextField();
        trainNameTextField.setBounds(120, 60, 150, 25);
        contentPanel.add(trainNameTextField);

        JLabel sourceLabel = new JLabel("From:");
        sourceLabel.setBounds(20, 100, 100, 25);
        sourceLabel.setForeground(Color.WHITE);
        sourceLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(sourceLabel);

        sourceTextField = new JTextField();
        sourceTextField.setBounds(120, 100, 150, 25);
        contentPanel.add(sourceTextField);

        JLabel destinationLabel = new JLabel("Destination:");
        destinationLabel.setBounds(20, 140, 100, 25);
        destinationLabel.setForeground(Color.WHITE);
        destinationLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(destinationLabel);

        destinationTextField = new JTextField();
        destinationTextField.setBounds(120, 140, 150, 25);
        contentPanel.add(destinationTextField);

        JLabel departureLabel = new JLabel("Departure:");
        departureLabel.setBounds(20, 180, 100, 25);
        departureLabel.setForeground(Color.WHITE);
        departureLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(departureLabel);

        departureTextField = new JTextField();
        departureTextField.setBounds(120, 180, 150, 25);
        contentPanel.add(departureTextField);

        JLabel arrivalLabel = new JLabel("Arrival:");
        arrivalLabel.setBounds(20, 210, 100, 25);
        arrivalLabel.setForeground(Color.WHITE);
        arrivalLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(arrivalLabel);

        arrivalTextField = new JTextField();
        arrivalTextField.setBounds(120, 210, 150, 25);
        contentPanel.add(arrivalTextField);

        JLabel priceLabel = new JLabel("Price:");
        priceLabel.setBounds(20, 240, 100, 25);
        priceLabel.setForeground(Color.WHITE);
        priceLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(priceLabel);

        priceTextField = new JTextField();
        priceTextField.setBounds(120, 240, 150, 25);
        contentPanel.add(priceTextField);

       
        insertTrainButton = new JButton("Insert");
        insertTrainButton.setBounds(20, 280, 120, 30);
        insertTrainButton.setFont(new Font("Consolas", Font.BOLD, 15));
        insertTrainButton.setForeground(Color.WHITE);
        insertTrainButton.setBackground(new Color(0, 102, 204));
        insertTrainButton.addActionListener(this);
        contentPanel.add(insertTrainButton);

        deleteTrainButton = new JButton("Delete");
        deleteTrainButton.setBounds(150, 280, 120, 30);
        deleteTrainButton.setFont(new Font("Consolas", Font.BOLD, 15));
        deleteTrainButton.setForeground(Color.WHITE);
        deleteTrainButton.setBackground(new Color(204, 0, 0));
        deleteTrainButton.addActionListener(this);
        contentPanel.add(deleteTrainButton);

        trainClearButton = new JButton("Clear");
        trainClearButton.setBounds(85, 320, 120, 30);
        trainClearButton.setFont(new Font("Consolas", Font.BOLD, 15));
        trainClearButton.setForeground(Color.WHITE);
        trainClearButton.setBackground(new Color(51, 51, 51));
        trainClearButton.addActionListener(this);
        contentPanel.add(trainClearButton);

        saveButton = new JButton("Save");
        saveButton.setBounds(85, 360, 120, 30);
        saveButton.setFont(new Font("Consolas", Font.BOLD, 15));
        saveButton.setForeground(Color.WHITE);
        saveButton.setBackground(new Color(0, 153, 76));
        saveButton.addActionListener(this);
        contentPanel.add(saveButton);

     
        JLabel pTrainNoLabel = new JLabel("Train No:");
        pTrainNoLabel.setBounds(20, 450, 100, 25);
        pTrainNoLabel.setForeground(Color.WHITE);
        pTrainNoLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(pTrainNoLabel);

        pTrainNoTextField = new JTextField();
        pTrainNoTextField.setBounds(120, 450, 150, 25);
        contentPanel.add(pTrainNoTextField);

        JLabel seatNoLabel = new JLabel("Seat No:");
        seatNoLabel.setBounds(20, 480, 100, 25);
        seatNoLabel.setForeground(Color.WHITE);
        seatNoLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(seatNoLabel);

        seatNoTextField = new JTextField();
        seatNoTextField.setBounds(120, 480, 150, 25);
        contentPanel.add(seatNoTextField);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(20, 510, 100, 25);
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(nameLabel);

        nameTextField = new JTextField();
        nameTextField.setBounds(120, 510, 150, 25);
        contentPanel.add(nameTextField);

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setBounds(20, 540, 100, 25);
        ageLabel.setForeground(Color.WHITE);
        ageLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(ageLabel);

        ageTextField = new JTextField();
        ageTextField.setBounds(120, 540, 150, 25);
        contentPanel.add(ageTextField);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(20, 570, 100, 25);
        genderLabel.setForeground(Color.WHITE);
        genderLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(genderLabel);

        String[] genders = {"Select", "Male", "Female", "Other"};
        genderComboBox = new JComboBox<>(genders);
        genderComboBox.setBounds(120, 570, 150, 25);
        contentPanel.add(genderComboBox);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(20, 600, 100, 25);
        phoneLabel.setForeground(Color.WHITE);
        phoneLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(phoneLabel);

        phoneTextField = new JTextField();
        phoneTextField.setBounds(120, 600, 150, 25);
        contentPanel.add(phoneTextField);

     
        insertPassengerButton = new JButton("Insert");
        insertPassengerButton.setBounds(20, 640, 120, 30);
        insertPassengerButton.setFont(new Font("Consolas", Font.BOLD, 15));
        insertPassengerButton.setForeground(Color.WHITE);
        insertPassengerButton.setBackground(new Color(0, 102, 204));
        insertPassengerButton.addActionListener(this);
        contentPanel.add(insertPassengerButton);

        deletePassengerButton = new JButton("Delete");
        deletePassengerButton.setBounds(150, 640, 120, 30);
        deletePassengerButton.setFont(new Font("Consolas", Font.BOLD, 15));
        deletePassengerButton.setForeground(Color.WHITE);
        deletePassengerButton.setBackground(new Color(204, 0, 0));
        deletePassengerButton.addActionListener(this);
        contentPanel.add(deletePassengerButton);

        passengerClearButton = new JButton("Clear");
        passengerClearButton.setBounds(85, 680, 120, 30);
        passengerClearButton.setFont(new Font("Consolas", Font.BOLD, 15));
        passengerClearButton.setForeground(Color.WHITE);
        passengerClearButton.setBackground(new Color(51, 51, 51));
        passengerClearButton.addActionListener(this);
        contentPanel.add(passengerClearButton);

        showReservedButton = new JButton("Show Reserved");
        showReservedButton.setBounds(85, 720, 120, 30);
        showReservedButton.setFont(new Font("Consolas", Font.BOLD, 15));
        showReservedButton.setForeground(Color.WHITE);
        showReservedButton.setBackground(new Color(0, 153, 76));
        showReservedButton.addActionListener(this);
        contentPanel.add(showReservedButton);

    
        JLabel searchLabel = new JLabel("Search Train (No/Name):");
        searchLabel.setBounds(350, 20, 200, 25);
        searchLabel.setForeground(Color.WHITE);
        searchLabel.setFont(new Font("Consolas", Font.BOLD, 15));
        contentPanel.add(searchLabel);

        searchTextField = new JTextField();
        searchTextField.setBounds(550, 20, 200, 25);
        contentPanel.add(searchTextField);

        searchButton = new JButton("Search");
        searchButton.setBounds(760, 20, 100, 30);
        searchButton.setFont(new Font("Consolas", Font.BOLD, 15));
        searchButton.setBackground(new Color(0, 102, 204));
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(this);
        contentPanel.add(searchButton);

        ImageIcon refreshIcon = new ImageIcon("./images/refresh.png");
        Image scaledRefresh = refreshIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        refreshButton = new JButton("Refresh");
        refreshButton.setBounds(900, 20, 100, 30);
        refreshButton.setFont(new Font("Consolas", Font.BOLD, 15));
        refreshButton.setBackground(new Color(51, 51, 51));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(this);
        contentPanel.add(refreshButton);

        JLabel refreshIconLabel = new JLabel(new ImageIcon(scaledRefresh));
        refreshIconLabel.setBounds(1005, 20, 40, 40);
        contentPanel.add(refreshIconLabel);

        
        String[] trainCols = {"No", "Name", "From", "Destination", "Departure", "Arrival", "Price"};
        trainTableModel = new DefaultTableModel(trainCols, 0);
        trainTable = new JTable(trainTableModel);
        trainTable.setFont(new Font("Consolas", Font.PLAIN, 15));
        trainTable.setRowHeight(25);
        trainTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        trainTable.setBorder(new LineBorder(Color.GRAY, 1));
        JScrollPane trainScroll = new JScrollPane(trainTable);
        trainScroll.setBounds(300, 60, 770, 250);
        contentPanel.add(trainScroll);

   
        String[] passCols = {"Seat", "Name", "Age", "Gender", "Phone", "Fare"};
        passengerTableModel = new DefaultTableModel(passCols, 0);
        passengerTable = new JTable(passengerTableModel);
        passengerTable.setFont(new Font("Consolas", Font.PLAIN, 15));
        passengerTable.setRowHeight(25);
        passengerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        passengerTable.setBorder(new LineBorder(Color.GRAY, 1));
        JScrollPane passScroll = new JScrollPane(passengerTable);
        passScroll.setBounds(300, 340, 770, 300);
        contentPanel.add(passScroll);

    
        availableSeatsLabel = new JLabel("Available Seats: ");
        availableSeatsLabel.setFont(new Font("Consolas", Font.BOLD, 18));
        availableSeatsLabel.setForeground(new Color(255, 215, 0));
        availableSeatsLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        availableSeatsLabel.setBounds(800, 650, 250, 30);
        contentPanel.add(availableSeatsLabel);

    
        setContentPane(background);
        background.setLayout(null);
        background.add(topPanel);
        background.add(contentPanel);

    
        FileIO.loadFromFile(trains);
        updateTrainTable();
        updatePassengerTable(null);

    
        trainTable.getSelectionModel().addListSelectionListener(e -> {
            int row = trainTable.getSelectedRow();
            if (row >= 0) {
                String trainNo = (String) trainTableModel.getValueAt(row, 0);
                int idx = findTrainByNumber(trainNo);
                if (idx != -1) updatePassengerTable(trains[idx]);
            }
        });
    }

    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == insertTrainButton) {
            insertTrain();
        } else if (e.getSource() == deleteTrainButton) {
            deleteTrain();
        } else if (e.getSource() == trainClearButton) {
            clearTrainFields();
        } else if (e.getSource() == saveButton) {
            FileIO.saveChangesInFile(trains);
            JOptionPane.showMessageDialog(this, "Data saved to file!");
        } else if (e.getSource() == insertPassengerButton) {
            bookTicket();
        } else if (e.getSource() == deletePassengerButton) {
            cancelTicket();
        } else if (e.getSource() == passengerClearButton) {
            clearPassengerFields();
        } else if (e.getSource() == showReservedButton) {
            showReservedTickets();
        } else if (e.getSource() == refreshButton) {
            FileIO.loadFromFile(trains);
            updateTrainTable();
            updatePassengerTable(null);
            JOptionPane.showMessageDialog(this, "Data refreshed from file!");
        } else if (e.getSource() == searchButton) {
            searchTrain();
        }
    }

    private void insertTrain() {
        try {
            String trainNo = trainNoTextField.getText().trim();
            String trainName = trainNameTextField.getText().trim();
            String source = sourceTextField.getText().trim();
            String destination = destinationTextField.getText().trim();
            String departure = departureTextField.getText().trim();
            String arrival = arrivalTextField.getText().trim();
            String priceStr = priceTextField.getText().trim();

            if (trainNo.isEmpty() || trainName.isEmpty() || source.isEmpty() ||
                destination.isEmpty() || departure.isEmpty() || arrival.isEmpty() || priceStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all train details!",
                        "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double price = Double.parseDouble(priceStr);

        
            if (findTrainByNumber(trainNo) != -1) {
                JOptionPane.showMessageDialog(this, "Train with this number already exists!",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Train newTrain = new Train(trainNo, trainName, source, destination, departure, arrival, price);
            boolean added = false;
            for (int i = 0; i < trains.length; i++) {
                if (trains[i] == null) {
                    trains[i] = newTrain;
                    added = true;
                    break;
                }
            }

            if (added) {
                updateTrainTable();
                clearTrainFields();
                JOptionPane.showMessageDialog(this, "Train added successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Cannot add more trains. Array is full.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid price format!",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteTrain() {
        String trainNo = trainNoTextField.getText().trim();
        int index = findTrainByNumber(trainNo);

        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Train not found!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this train?",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            
            for (int i = index; i < trains.length - 1; i++) {
                trains[i] = trains[i+1];
            }
            trains[trains.length - 1] = null;

            updateTrainTable();
            clearTrainFields();
            updatePassengerTable(null);
            JOptionPane.showMessageDialog(this, "Train deleted successfully!");
        }
    }

    private void bookTicket() {
        try {
            String trainNo = pTrainNoTextField.getText().trim();
            String seatNoStr = seatNoTextField.getText().trim();
            String name = nameTextField.getText().trim();
            String ageStr = ageTextField.getText().trim();
            String gender = (String) genderComboBox.getSelectedItem();
            String phone = phoneTextField.getText().trim();

            if (trainNo.isEmpty() || seatNoStr.isEmpty() || name.isEmpty() || ageStr.isEmpty() || gender.equals("Select") || phone.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all passenger details!",
                        "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int seatNo = Integer.parseInt(seatNoStr);
            int age = Integer.parseInt(ageStr);

            if (seatNo < 1 || seatNo > 100) {
                JOptionPane.showMessageDialog(this, "Seat number must be between 1 and 100.",
                        "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int trainIndex = findTrainByNumber(trainNo);
            if (trainIndex == -1) {
                JOptionPane.showMessageDialog(this, "Train not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Train train = trains[trainIndex];
            if (train.isSeatBooked(seatNo - 1)) { 
                JOptionPane.showMessageDialog(this, "Seat " + seatNo + " is already booked!",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Passenger newPassenger = new Passenger(name, age, gender, phone, String.valueOf(seatNo), train.getTicketPrice());
            boolean booked = train.bookSeat(seatNo - 1, newPassenger); 

            if (booked) {
                updatePassengerTable(train);
                clearPassengerFields();
                JOptionPane.showMessageDialog(this, "Ticket booked successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to book ticket!", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input for age or seat number",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cancelTicket() {
        try {
            String trainNo = pTrainNoTextField.getText().trim();
            int seatNo = Integer.parseInt(seatNoTextField.getText().trim());

            if (trainNo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter train number.",
                        "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (seatNo < 1 || seatNo > 100) {
                JOptionPane.showMessageDialog(this, "Seat number must be between 1 and 100.",
                        "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int trainIndex = findTrainByNumber(trainNo);
            if (trainIndex == -1) {
                JOptionPane.showMessageDialog(this, "Train not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Train train = trains[trainIndex];
            if (!train.isSeatBooked(seatNo - 1)) {
                JOptionPane.showMessageDialog(this, "Seat " + seatNo + " is not booked.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (JOptionPane.showConfirmDialog(this, "Are you sure you want to cancel ticket for seat " + seatNo + "?",
                    "Confirm Cancellation", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                train.cancelSeat(seatNo - 1);
                updatePassengerTable(train);
                clearPassengerFields();
                JOptionPane.showMessageDialog(this, "Ticket canceled successfully!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input for seat number!",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showReservedTickets() {
        String trainNo = pTrainNoTextField.getText().trim();
        int trainIndex = findTrainByNumber(trainNo);

        if (trainIndex == -1) {
            JOptionPane.showMessageDialog(this, "Train not found!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        updatePassengerTable(trains[trainIndex]);
        clearPassengerFields();
    }

    private void searchTrain() {
        String search = searchTextField.getText().trim().toLowerCase();
        trainTableModel.setRowCount(0);
        for (Train t : trains) {
            if (t != null && (t.getTrainNumber().toLowerCase().contains(search) || t.getTrainName().toLowerCase().contains(search))) {
                trainTableModel.addRow(new Object[]{
                    t.getTrainNumber(), t.getTrainName(), t.getFrom(), t.getDestination(),
                    t.getDepartureTime(), t.getArrivalTime(), t.getTicketPrice()
                });
            }
        }
    }

    private int findTrainByNumber(String trainNumber) {
        for (int i = 0; i < trains.length; i++) {
            if (trains[i] != null && trains[i].getTrainNumber().equals(trainNumber)) {
                return i;
            }
        }
        return -1;
    }

    private void updateTrainTable() {
        trainTableModel.setRowCount(0);
        for (Train t : trains) {
            if (t != null) {
                trainTableModel.addRow(new Object[]{
                    t.getTrainNumber(), t.getTrainName(), t.getFrom(), t.getDestination(),
                    t.getDepartureTime(), t.getArrivalTime(), t.getTicketPrice()
                });
            }
        }
    }

    private void updatePassengerTable(Train train) {
        passengerTableModel.setRowCount(0);
        if (train != null) {
            for (Passenger p : train.getAllPassengers()) {
                if (p != null) {
                    passengerTableModel.addRow(new Object[]{
                        p.getSeatNumber(), p.getPassengerName(), p.getAge(), p.getGender(), p.getPhoneNumber(), p.getTicketPrice()
                    });
                }
            }
            availableSeatsLabel.setText("Available Seats: " + train.getAvailableSeats());
        } else {
            availableSeatsLabel.setText("Available Seats: ");
        }
    }

    private void clearTrainFields() {
        trainNoTextField.setText("");
        trainNameTextField.setText("");
        sourceTextField.setText("");
        destinationTextField.setText("");
        departureTextField.setText("");
        arrivalTextField.setText("");
        priceTextField.setText("");
    }

    private void clearPassengerFields() {
        pTrainNoTextField.setText("");
        seatNoTextField.setText("");
        nameTextField.setText("");
        ageTextField.setText("");
        phoneTextField.setText("");
        genderComboBox.setSelectedIndex(0);
    }
}
